Federal Digital Banking Demo
Demo login: customer / bank123